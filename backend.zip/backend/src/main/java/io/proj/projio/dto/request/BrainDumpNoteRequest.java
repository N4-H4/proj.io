package io.proj.projio.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BrainDumpNoteRequest {

    @NotBlank(message = "Content is required")
    private String content;

    private Long projectId;
}
